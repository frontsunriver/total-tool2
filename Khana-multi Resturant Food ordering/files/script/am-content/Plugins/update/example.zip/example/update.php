<?php 
function update()
{
	//for file
	$data['file']=array(
		'file'=>'uploads/update/exampledir/theme.json',
		'root'=>base_path().'/am-content/Themes/theme.json'
	);
	//for dir
	$data['dir']=array(
		'file'=>'uploads/update/exampledir/exampledir',
		'root'=>base_path().'/am-content/Themes'
	);

	return $data;
}


?>