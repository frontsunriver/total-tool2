<?php 
function update()
{
	$data = array();
	//for dir
	$data[]=array(
		'type'=>'dir',
		'file'=>'uploads/update/v2.2/cache/',
		'root'=>base_path().'/am-content/Plugins'
	);

	//for file
	$data[]=array(
		'type'=>'file',
		'file'=>'uploads/update/v2.2/plugin.json',
		'root'=>base_path().'/am-content/Plugins/plugin.json'
	);
	//for file
	$data[]=array(
		'type'=>'file',
		'file'=>'uploads/update/v2.2/menuregister.php',
		'root'=>base_path().'/am-content/Plugins/menuregister.php'
	);
	//for file
	$data[]=array(
		'type'=>'file',
		'file'=>'uploads/update/v2.2/helper.php',
		'root'=>base_path().'/app/helper/helper.php'
	);

	//for file
	$data[]=array(
		'type'=>'file',
		'file'=>'uploads/update/v2.2/edit.blade.php',
		'root'=>base_path().'/am-content/Plugins/shop/views/products/edit.blade.php'
	);

	$data[]=array(
		'type'=>'file',
		'file'=>'uploads/update/v2.2/register_step_1.blade.php',
		'root'=>base_path().'/am-content/Themes/khana/views/store/register_step_1.blade.php'
	);

	$data[]=array(
		'type'=>'file',
		'file'=>'uploads/update/v2.2/register_step_2.blade.php',
		'root'=>base_path().'/am-content/Themes/khana/views/store/register_step_2.blade.php'
	);

	//for file
	$data[]=array(
		'type'=>'file',
		'file'=>'uploads/update/v2.2/Lphelper.php',
		'root'=>base_path().'/vendor/lpress/src/Lphelper.php'
	);

	//for file
	$data[]=array(
		'type'=>'file',
		'file'=>'uploads/update/v2.2/form.js',
		'root'=>'admin/js/form.js'
	);

	return $data;
}


?>